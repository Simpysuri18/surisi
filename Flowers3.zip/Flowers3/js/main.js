/* Alex Tetervak, Sheridan College, Ontario */

"use strict"; // use the strict mode

// starts using jQuery
$(function() {
    // load the xml file
    $.get("data/catalog.xml",displayFlowers);
});

// make the table
function displayFlowers(xml){
    let $table = $("<table></table>");
    $table.appendTo("main");
    let $flowers = $(xml).find("flower");
    $flowers.each(function(){
        let name = $(this).attr("name");
        let label = $(this).find("label").text();
        let price = $(this).find("price").text();
        let text = $(this).find("text").text();
        let imageFile  = $(this).find("image[size='small']:first").text();
        $table.append(
            `<tr> 
                <td>
                    <img src="images/flowers/${imageFile}" alt="${name}">
                </td> 
                <td>
                    <span class="flower_label">${label}</span>&nbsp;&nbsp;
                    <span class="flower_price">${price}</span><br>
                    ${text}
                </td>
            </tr>`
        );
    });

}

