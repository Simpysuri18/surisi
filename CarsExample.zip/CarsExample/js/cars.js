$(document).on('pagebeforeshow', '#home', function (e, data) {
    $.ajax({
        type: "GET",
        url: "cars.xml",
        dataType: "xml",
        success: listCars,
        error: function (e) {
            alert(e.status + "-" + e.statusText);
        }
    });
});

function listCars(xml) {
    $(xml).find("car").each(function (n) {
        $(".car" + (n + 1)).text($(this).find("name").text());
    });
};

$(document).on('pagebeforeshow', '#toyota', function () {
    $('#cars-toyota').html("");
    console.log("in toyota");							//used for debug - comment out when working
    $.ajax({
        type: "GET",
        url: "cars.xml",
        dataType: "xml",
        success: function (xml) {
            parseXML(xml, "TOYOTA")
        },			// to send multiple parameters
        error: function (request, error) {
            alert('Network error has occurred: ' + error);
        }
    });
});

$(document).on('pagebeforeshow', '#ford', function () {
    $('#cars-ford').html("");
    $.ajax({
        type: "GET",
        url: "cars.xml",
        dataType: "xml",
        success: function (xml) {
            parseXML(xml, "FORD");
        },
        error: function (request, error) {
            alert('Network error has occurred:  ' + error);
        }
    });
});

function parseXML(xml, name) {
    console.log("in parseXML");						//used for debug - comment out when working
    $(xml).find("car").each(function () {
        console.log("in car loop");						//used for debug - comment out when working
        if (name === $(this).find('name').text()) {
            console.log("in if - " + name);			//used for debug - comment out when working
            $("#cars-" + name.toLowerCase()).append("<img src='images/" +
                $(this).find('pic').text() + "' height='20%' width='20%'/>" +
                "<h3>Car type: " + $(this).find('name').text() + "</h3>" +
                "<h4>Country: " + $(this).find('country').text() + "</h4>" +
                "<p>" + $(this).find('description').text() + "</p>");
        }
    });
}


