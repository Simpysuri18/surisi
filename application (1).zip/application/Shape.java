package application;

public class Shape {
	public int color;
	
	
}
