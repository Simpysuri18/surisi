"use strict"; // use the strict mode

// to store the cat names
//const cats = ["russianblue", "norwegianforestcat", "persiancat", "scottishfold", "britishshorthair"];
// starts using jQuery
$(function () {
    // load the xml file
    $.get("catalog.xml", processXML);

});

// the array to store the data loaded from XML file
let cats = [];

// process the XML file
function processXML(xml) {
    // extract the data from XML and store the data in the array of cats
    extractData(xml);
    // make the list of small images
    makeImageList();
    // insert the first cat large image and info
    displayCat(0);
    // make the first image look selected
    selectFirstImage();
    // make the small images clickable
    setupClicks();
    updateLinks(0);

}

// extracts the data from XML and stores the data in the array of flowers
function extractData(xml) {
    let $cats = $(xml).find("cat");
    $cats.each(function () {
        let cat = {}; // empty cat object
        // pick data for the cat object from XML
        cat.name = $(this).attr("name");
        cat.label = $(this).find("label").text();
        cat.price = $(this).find("price").text();
        cat.text = $(this).find("text").text();
        const imageFolder = 'images/';
        cat.smallImageSrc = imageFolder + $(this).find("image[size='small']:first").text();
        cat.largeImageSrc = imageFolder + $(this).find("image[size='large']:first").text();
        // preload the small and the large images for the flower
        cat.smallImage = new Image();
        cat.smallImage.src = cat.smallImageSrc;
        cat.largeImage = new Image();
        cat.largeImage.src = cat.largeImageSrc;
        // add the flower object to the array of flowers
        cats.push(cat);

    });
}

// makes the list of the small images
function makeImageList() {
    let $list = $("#images_list");
    cats.forEach(function (cat, index) {
        let $img = $(`<img src="${cat.smallImageSrc}">`);
        $img.attr("alt", cat.label);
        $img.attr("data-index", index);
        $img.addClass("thumb");
        let $li = $("<li></li>");
        $img.appendTo($li);
        $li.appendTo($list);
    });
}


// hide or disable link
function disableButton(selector) {
    $(selector).hide();
}

function updateButton(selector, index) {
    $(selector).show();
    $(selector).attr("data-index", index);
}

function updateLinks(index) {
    if (index === 0) {
        // first flower
        // hide the previous link
        disableButton(".previous");
        // update data index in the next link
        updateButton(".next", index + 1);

        //$("prev_link").hide();
    } else if (index === (cats.length - 1)) {
        // last flower
        // update data-index in the previous link
        //  $("#prev_link").attr("data-index", index-1);
        updateButton(".previous", index - 1);
        // make sure that the previous link is shown (if you keep the small images )
        //hide the next link
        disableButton('.next');
        // next link
    } else {
        // any other flower
        // update data-index for both links
        updateButton(".previous", index - 1);
        updateButton(".next", index + 1);
        //$("#prev_link").attr("data-index", index-1);
        //	$("#next_link").attr("data-index",index +1);
        // make sure that both are shown

    }


}

// display the cat
function displayCat(index) {
    let cat = cats[index];
    $("span.cat_name").text(cat.label);
    $("img.cat_images").attr("src", cat.largeImageSrc).attr("alt",cat.label);
    $("p.cat_details").text(cat.text);
}

// make the first image look selected
function selectFirstImage() {
    $("#images_list img:first").addClass("selected");
}


// make the small images clickable
function setupClicks() {
    $("img.thumb").click(function () {
        $("#images_list img.selected").removeClass("selected");
        $(this).addClass("selected");
        displayCat($(this).data("index"));
    });

    //handle previous and next links here
    $(".previous,.next").click(function () {
        let index = parseInt($(this).attr("data-index"));
        updateLinks(index);
        displayCat(index);
        selectSmallImage(index);
    });
    function selectSmallImage(index){
        $("#images_list img.selected").removeClass("selected");
        $(`#images_list img:eq(${index})`).addClass("selected");
    }
}