// Name: Simpy Suri
// Student Number: 991070013
//Professor: Amandeep Patti

import java.util.Scanner;

public class Assignment4{
  public static void main(String[] args){
    
    Scanner input = new Scanner(System.in);

    System.out.println("Account Number is : ");
    int number = input.nextInt();

    System.out.print("Opening Account Balance is: ");
    double balance = input.nextDouble ();

    System.out.print("Rate of Interest is : ");
    double rate = input.nextDouble ();

    Account account = new Account(number, balance);
    
    account.setAnnualInterestRate(rate);   
    account.withdraw(2500);  
    account.deposit(3000); 

    System.out.println("Balance is " + account.getBalance());   
    System.out.println("Monthly interest is " + account.getMonthlyInterest());

  }
}

 class Account{
  
  private int _number1;
  private double _balance1;
  private double _rate;
 
 
  public Account() {
    _number1 = 123;
    _balance1 = 0.0;  
    _rate = 0.0;
    
  }
  
  public Account(int number, double balance) {
    _number1 = number;
    _balance1 = balance;
   
  }
   
  public  void setAnnualInterestRate(double rate){
    _rate = rate ;
  }
  
  public void setBalance(double balance) {
    _balance1 = balance;
  }
  
  public  double getBalance(){
    return _balance1;
  }
  
   public  double getAnnualInterestRate(){
    return _rate;
  }
  
  
  public  double getMonthlyInterest(){ 
    return _rate/12;
    
  }
  
  public double  withdraw(double withdrawAmount){
    _balance1 = _balance1-withdrawAmount;
    return _balance1;
  }
  
  public double deposit(double depositAmount){
    _balance1 = _balance1 + depositAmount;
    return _balance1;
  }
}
    
