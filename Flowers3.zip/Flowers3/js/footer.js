// Alex Tetervak, Sheridan College, Ontario

"use strict"; // use the strict mode

$(function () {
    // insert the page footer with the current year
    $("body").append("<footer></footer>");
    $("footer")
        .html("Sheridan College&nbsp;&nbsp;<span style='color: indianred'>&#9825;</span>&nbsp;&nbsp;")
        .append((new Date()).getFullYear());
});