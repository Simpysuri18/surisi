// Student Name: Simpy Suri
// Student Id : 991070013
import java.util.Scanner;
import java.lang.Math;

public class Stonegame
{
  public static void main(String [] args)
  {
 Scanner input=new Scanner(System.in);

 // starting sentences of the code for explanation purposes
   System.out.println("Number of stones is 21" );
   // declare variable for how many stones will be left
  int remaining=21;
   int comturn;
    int total=21;
  // do while loop 
    do
    {

   // declare void variable for computer turn and for the toal number of stones, 21.
   
        
  // S.O.U.T stament for user picking stones
    System.out.println("User Pick stones:");
    
    // variable declaration in which the user is asked to input the number of stones they want
    int uin= input.nextInt();
    // declare variable for how much will be left after user asks for stones
   
    
   // if else staments for the computer to know what should be done if each condition is true or false
    if(uin<1 || uin>3)
    {
      
      System.out.println("Invalid pick. Kindly try again \n");
       uin= input.nextInt();
      
    }
    else if(uin>=0 || uin<= 3)
    {
    
     
    }
    else
    {
      System.out.println("Invalid pick. Kindly try again \n");
    }
    remaining-= uin;
    System.out.println(" Number of stonespicked by user is :"+ uin+ "\nRemaining Stones: "+ remaining);
    if ( remaining<0){
      System.out.println("Computer Win");
    }
    System.out.println("Computer turn");
   
    // computer turn variable redeclared for the purpose of genereating random numbers
    comturn = (int)(Math.random ()*3) +1;
   
    // final redeclaration for remaining stones, when the code runs again the remaining variable will have correct number for it's value remaining.
    remaining -= comturn;
   
    System.out.println (" The computer chose " + comturn);
   // S.O.U.T for how many stones remain
   System.out.println ("Stones remaining" + remaining);
    
    } while(remaining !=0); // while condition for the purpose ending loop. The condition says that the should run until reamining value is 0
      // after the loop ends prints that the computer wins
     System.out.println(" The computer wins");
}
}