package application;

public class Square {
	public int x1;
	public int y1;
	public int x2;
	public int y2;
}
