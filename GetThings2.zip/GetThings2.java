/**
 * File name: GetThings2.java
 * 
 * Description: Create the code that will enable karel to pick up all
 * the things. Do it as efficiently as possible using your methods.
 */

import becker.robots.*;

public class GetThings2 {
    
    public static void main(String[] args) {
        
        // Create the city
        City brampton = new City();
        
        // Create the robot at intersection of Street 1 Avenue 0 facing East
        Robot karel = new Robot(brampton, 1, 0, Direction.EAST);
        
        // Create 13 things
        Thing t1 = new Thing(brampton, 3, 0);
        Thing t1a = new Thing(brampton, 3, 1);
        Thing t2 = new Thing(brampton, 2, 1);
        Thing t3 = new Thing(brampton, 4, 1);
        Thing t4 = new Thing(brampton, 1, 2);
        Thing t4a = new Thing(brampton, 1, 4);
        Thing t5 = new Thing(brampton, 5, 2);
        Thing t5a = new Thing(brampton, 5, 0);
        Thing t5b = new Thing(brampton, 5, 2);
        Thing t5c = new Thing(brampton, 5, 4);
        Thing t6 = new Thing(brampton, 2, 3);
        Thing t7 = new Thing(brampton, 4, 3);
        Thing t8 = new Thing(brampton, 3, 4);
        
        // ****** Put your code between these lines ******
        
      for(int i = 0; i < 5 ; i++)
        {
        moveUpTo(karel,4);
        goNextAvenue(karel);
        }
        
        moveIntersection(karel,5,4);

        
        // ****** Put your code between these lines ******
        
    }
    
    
    // ****** Add your methods below this line ******
    public static int moveToWall(Robot robotCall)
    {
      int count = 0;
      while(robotCall.frontIsClear()){
        robotCall.move();
        count = count+1;
      }
      return count;
    }
    public static void turnRight(Robot robotCall){
    
    for( int i = 0 ; i < 3 ; i++)
    robotCall.turnLeft();
    
    } // ***** end of turnRight **********
  
  public static void moveSpaces(Robot robotCall , int numberOfSpaces){
    
    for( int i = 0 ; i < numberOfSpaces ; i++)
      robotCall.move();
  }
  public static void pickAllThings(Robot robotCall)
  {
    while(robotCall.canPickThing()){
      robotCall.pickThing();
    }
  } 
  public static void moveUpTo(Robot robotCall, int spaces)
  {
    for(int i = 0 ; i < spaces; i++)
    { 
      
      pickAllThings(robotCall);
      robotCall.move();
      pickAllThings(robotCall);
      
    }
    
  }
  public static void goNextAvenue(Robot robotCall)
  {
    if((robotCall.getDirection())== Direction.EAST)
    {
      turnRight(robotCall);
      robotCall.move();
      turnRight(robotCall);
    }
    else if((robotCall.getDirection())== Direction.WEST)
    {
      robotCall.turnLeft();
      robotCall.move();
      robotCall.turnLeft();
    }
  }
  public static void moveIntersection(Robot robotCall, int street, int avenue)
  {
        for(int i = 0; i < (street -robotCall.getStreet()); i++)
        {
        moveUpTo(robotCall,(avenue - robotCall.getAvenue()) );
        goNextAvenue(robotCall);
        }
  }
}
    
