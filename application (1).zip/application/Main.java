package application;
	
import java.util.ArrayList;
import java.util.Random;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;


public class Main extends Application {
	static final int WIDTH = 800;
	static final int HEIGHT = 600;
	public static ArrayList<Circle> circleArr = new ArrayList<Circle>();
	private Canvas canvas;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			primaryStage.setTitle("Shape Animator");
			BorderPane root = new BorderPane();
			Scene scene = new Scene(root,WIDTH,HEIGHT);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			
			canvas = new Canvas();
			root.setCenter(canvas);
			canvas.setWidth(WIDTH);
			canvas.setHeight(HEIGHT);
			
			//canvas.getGraphicsContext2D().strokeOval(0, 0, 100, 100);
			
			Button circleButton = new Button("Circle");
			FlowPane buttonPane = new FlowPane();
			buttonPane.getChildren().add(circleButton);
			root.setBottom(buttonPane);
			
			circleButton.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent e) {
					Random rand = new Random();
					
					// 1. Create a circle object
					Circle c = new Circle();
					c.x = rand.nextInt(WIDTH);
					c.y = rand.nextInt(HEIGHT);
					c.r = rand.nextInt(300);
					
					// 2. Store the object in the arraylist
					circleArr.add(c);
					
					// 3. Loop through the array list and draw all the circles on screen
					refreshScreen();
				}
			});
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void refreshScreen() {
		//for (Circle c : circleArr) {
		for(int i = 0; i < circleArr.size(); i++) {
			Circle c = circleArr.get(i);
			canvas.getGraphicsContext2D().strokeOval(c.x, c.y, c.r, c.r);
			
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
