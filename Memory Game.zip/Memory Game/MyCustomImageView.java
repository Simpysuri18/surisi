package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class MyCustomImageView extends ImageView {
	public MyCustomImageView(Image img) {
		super(img);
	}
	
	// Inherit everything from JavaFX's ImageView, but
	// add two more fields: row and col
	public int row;
	public int col;
}
