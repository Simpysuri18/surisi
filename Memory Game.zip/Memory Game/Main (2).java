package application;
	
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;


public class Main extends Application {
	
	private final int GRID_SIZE = 2;
	
	int[][] board = new int[][] {{1,2}, {2,1}};
	
	int previous = -1;
	int current = -1;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			primaryStage.setTitle("GUI Demo");
			BorderPane root = new BorderPane();
			Scene scene = new Scene(root,800,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			
			FlowPane buttonPanel = new FlowPane();
			buttonPanel.setAlignment(Pos.CENTER);
			
			GridPane imagePanel = new GridPane();
			//imagePanel.setAlignment(Pos.CENTER);
			
			root.setCenter(imagePanel);
			root.setBottom(buttonPanel);
			
			Button happyBtn = new Button("Happy");
			Button sadBtn = new Button("Sad");
			buttonPanel.getChildren().add(happyBtn);
			buttonPanel.getChildren().add(sadBtn);
			
			Image flippedImg = new Image("flipped.png");
			//Image happyImg = new Image("happy.jpg");
			//Image sadImg = new Image("sad.jpg");
			
			for (int r = 0; r < GRID_SIZE; r++) {
				for (int c = 0; c < GRID_SIZE; c++) {
					MyCustomImageView imgView = 
							new MyCustomImageView(flippedImg);
					imgView.row = r;
					imgView.col = c;
					
					imagePanel.add(imgView, r, c);

					imgView.setOnMouseClicked(new EventHandler<MouseEvent>() {
						@Override
						public void handle(MouseEvent event) {
							previous = current;
							current = board[imgView.row][imgView.col];
							System.out.println("Previous = " + previous + " Current = " + current);

							Image currentImg = new Image(current + ".jpg");
							imgView.setImage(currentImg);
						}
					});
				}
			}
			
			sadBtn.setOnAction(new EventHandler<ActionEvent>() {
	            @Override public void handle(ActionEvent e) {
//	                imgView.setImage(sadImg);
	            }
	        });
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
